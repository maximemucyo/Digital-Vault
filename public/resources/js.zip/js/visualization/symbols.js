document.addEventListener('DOMContentLoaded', () => {
    const dropdown = document.getElementById('symbolDropdown');

    const exampleSymbols = [
        'BTCUSDT',  
        'DOGEUSDT',
        'ETHUSDT',  
        'BNBUSDT',  
        'BTCBUSD',  
        'ETHBUSD', 
        'LTCUSDT',  
    ];

    // Populate dropdown with example symbols
    exampleSymbols.forEach(symbol => {
        const option = document.createElement('option');
        option.value = symbol;
        option.textContent = symbol;
        dropdown.appendChild(option);
    });


    // Notify when a symbol is selected or the default symbol is set
    function notifySymbol(symbol) {
        document.dispatchEvent(new CustomEvent('symbolSelected', { detail: symbol }));
    }

    dropdown.addEventListener('change', (event) => {
        const selectedSymbol = event.target.value;
        dropdown.value =selectedSymbol;
        if (selectedSymbol) {
            notifySymbol(selectedSymbol);
        }
    });
 
});
